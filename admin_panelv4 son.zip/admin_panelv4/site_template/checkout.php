﻿<?php
include("config.php");
include "header.php";
include "main_nav.php";
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="bread"><a href="#">Home</a> &rsaquo; Checkout</div>
                            <div class="bigtitle">Checkout</div>
                        </div>
                        <div class="col-md-3 col-md-offset-5"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="title-bg">
        <div class="title">Checkout</div>
    </div>

    <?php
    if (isset($_SESSION['error'])) {
        echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
        unset($_SESSION['error']);
    }
    ?>

    <div class="table-responsive">
        <table class="table table-bordered chart">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Item No.</th>
                    <th>Unit Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $totalPrice = 0;

                // Sepetteki ürünleri veritabanından çek
                $sql = "SELECT c.product_id, c.quantity, p.product_name, p.product_price, p.product_image
                        FROM cart_table c
                        JOIN product_table p ON c.product_id = p.product_id";
                $cartItems = berkhoca_query_parser($sql);

                if ($cartItems && count($cartItems) > 0) {
                    foreach ($cartItems as $cartItem) {
                        echo '<tr>
                            <td><img src="../product_images/' . $cartItem['product_image'] . '" width="100" alt=""></td>
                            <td>' . $cartItem['product_name'] . '</td>
                            <td>' . $cartItem['product_id'] . '</td>
                            <td>' . $cartItem['product_price'] . '</td>
                            <td>' . $cartItem['quantity'] . '</td>
                            <td>' . $cartItem['product_price'] * $cartItem['quantity'] . '</td>
                        </tr>';

                        $totalPrice += $cartItem['product_price'] * $cartItem['quantity'];
                    }
                } else {
                    echo '<tr><td colspan="6">Your cart is empty.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <div class="row">
        <div class="col-md-6">
            <form class="form-horizontal coupon" role="form">
                <div class="form-group">
                    <label for="coupon" class="col-sm-3 control-label">Coupon Code</label>
                    <div class="col-sm-7">
                        <input type="email" class="form-control" id="coupon" placeholder="Email">
                    </div>
                    <div class="col-sm-2">
                        <button class="btn btn-default btn-red btn-sm">Apply</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-3 col-md-offset-3">
            <div class="subtotal-wrap">
                <div class="subtotal">
                    <p>Total Price: $<?php echo $totalPrice; ?></p>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <form action="confirm_order.php" method="post">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="name">Surname:</label>
                    <input type="text" class="form-control" id="surname" name="surname" required>
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" class="form-control" id="address" name="address" required>
                </div>
                <div class="form-group">
                    <label for="name">City:</label>
                    <input type="text" class="form-control" id="city" name="city" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone:</label>
                    <input type="text" class="form-control" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <!-- Fake Credit Card Fields -->
                <div class="form-group">
                    <label for="card_number">Card Number:</label>
                    <input type="text" class="form-control" id="card_number" name="card_number" placeholder="**** **** **** ****" required>
                </div>
                <div class="form-group">
                    <label for="card_name">Card Holder Name:</label>
                    <input type="text" class="form-control" id="card_name" name="card_name" required>
                </div>
                <div class="form-group">
                    <label for="card_expiry">Expiration Date:</label>
                    <input type="text" class="form-control" id="card_expiry" name="card_expiry" placeholder="MM/YY" required>
                </div>
                <div class="form-group">
                    <label for="card_cvv">CVV:</label>
                    <input type="text" class="form-control" id="card_cvv" name="card_cvv" placeholder="***" required>
                </div>
                <!-- End Fake Credit Card Fields -->
                <button type="submit" class="btn btn-default btn-yellow">Confirm Order</button>
            </form>
        </div>
    </div> 
    <?php include "footer.php"; ?>       
        
