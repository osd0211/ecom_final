﻿<?php
include("config.php");

$conn = new mysqli("localhost", "root", "", "berkhoca_db");

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$sql = "SELECT p.*, c.category_name 
        FROM product_table p 
        LEFT JOIN category_table c 
        ON p.category_id = c.category_id
        WHERE p.product_stock > 0";
$result = $conn->query($sql);

$products = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        
        if (file_exists("../product_images/" . $row['product_image'])) {
            $row['product_image'] = "../product_images/" . $row['product_image']; 
            $products[] = $row;
        } else {
            $row['product_image'] = 'default.jpg'; 
            $products[] = $row;
        }
    }
}
?>

<?php include "header.php"; ?>
<?php include "main_nav.php"; ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="bread"><a href="#">Home</a> &rsaquo; Products</div>
                            <div class="bigtitle">Products</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9">
            <div class="title-bg">
                <div class="title">All products</div>
                <div class="title-nav">
                    
                </div>
            </div>
            <div class="row prdct" style="display: flex; flex-wrap: wrap;">
                <?php foreach ($products as $product): ?>
                    <div class="col-md-4">
                        <div class="productwrap">
                            <div class="pr-img">
                                <a href="product.php?product_id=<?php echo $product['product_id']; ?>">
                                    <img src="<?php echo $product['product_image']; ?>" alt="" class="img-responsive">
                                </a>
                                <div class="pricetag"><div class="inner">$<?php echo $product['product_price']; ?></div></div>
                            </div>
                            <span class="smalltitle">
                                <a href="product.php?product_id=<?php echo $product['product_id']; ?>">
                                    <?php echo $product['product_name']; ?>
                                </a>
                            </span>
                            <span class="smalldesc">Item no.: <?php echo $product['product_id']; ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
        </div>
        <?php include "sidebar.php"; ?>
    </div>
</div>
<?php include "footer.php"; ?>
