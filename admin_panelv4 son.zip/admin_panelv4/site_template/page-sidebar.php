﻿<?php include "header.php"; ?>
<?php include "main_nav.php"; ?>
	
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="page-title-wrap">
					<div class="page-title-inner">
					<div class="row">
						<div class="col-md-4">
							<div class="bread"><a href="#">Home</a> &rsaquo; About</div>
							<div class="bigtitle">About</div>
						</div>
						<!-- <div class="col-md-3 col-md-offset-5">
							<button class="btn btn-default btn-red btn-lg">Purchase Theme</button>
						</div> -->
					</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-9"><!--Main content-->
				<div class="title-bg">
					<div class="title">About Shopping</div>
				</div>
				<div class="page-content">
					<p>
					 I am Ömer Şerif Dağlı. I was born in 2001. I am actively continuing my student life in the computer engineering department at Maltepe University. 
					</p>
					<p>
					My aim in this project is not to waste the efforts of my dear teacher Berk Kanburlar. I tried to do it as carefully as I could. Thank you very much.

					</p>
				</div>
			</div>


	<?php include "sidebar.php"; ?>
	
	</div>
	
	
	<?php include "footer.php"; ?>