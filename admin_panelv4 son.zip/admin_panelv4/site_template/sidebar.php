<div class="col-md-3"><!--sidebar-->
    <div class="title-bg">
        <div class="title">Categories</div>
    </div>
    
    <div class="categorybox">
        <ul>
            <?php
            include 'config.php'; // Veritabanı bağlantı bilgilerini içe aktar
            $sql = "SELECT category_id, category_name FROM category_table";
            $categories = berkhoca_query_parser($sql); // Kategorileri çek

            foreach ($categories as $category) {
                echo '<li><a href="category_products.php?category_id=' . $category["category_id"] . '">' . $category["category_name"] . '</a></li>';
            }
            ?>
        </ul>
    </div>
    
    <div class="ads">
        <a href="https://www.instagram.com/berkkanburlar/"><img src="images\ayzek.jpg" class="img-responsive" alt=""></a>
    </div>
</div><!--sidebar-->
