<?php
// session_start(); 

include("config.php");


$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
$quantity = isset($_GET['quantity']) ? (int)$_GET['quantity'] : 1;

if ($product_id && $quantity > 0) {
    
    $sql = "SELECT * FROM product_table WHERE product_id = $product_id";
    $result = berkhoca_query_parser($sql); 

    if($result && count($result) > 0) {
        $row = $result[0]; 

        
        if($row['product_stock'] >= $quantity) {
            $found = false;
            
            if(isset($_SESSION['cart'])) {
                foreach($_SESSION['cart'] as $key => $item) {
                    if($item['id'] == $product_id) {
                        $found = true;
                        $_SESSION['cart'][$key]['quantity'] += $quantity; 
                        break;
                    }
                }
            }

            if(!$found) {
                
                $_SESSION['cart'][] = array(
                    'name' => $row['product_name'],
                    'id' => $row['product_id'],
                    'price' => $row['product_price'],
                    'image' => $row['product_image'],
                    'quantity' => $quantity
                );
            }
        } else {
            echo '<div class="container"><div class="alert alert-danger">Üzgünüz, bu ürün stok limitine ulaştı.</div></div>';
        }
    }
} else {
    echo '<div class="container"><div class="alert alert-danger">Geçersiz ürün ID veya miktar!</div></div>';
}


header("Location: cart3.php");
exit;
?>
