﻿<?php 
include "config.php";

// Get the product ID
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

if ($product_id) {
    // Fetch product details from the database
    $sql = "SELECT p.*, c.category_name 
            FROM product_table p 
            LEFT JOIN category_table c 
            ON p.category_id = c.category_id
            WHERE p.product_id = $product_id";
    
    $product = berkhoca_query_parser($sql);

    if (!empty($product)) {
        $product = $product[0];
    } else {
        echo "<div class='container'><div class='alert alert-danger'>Product not found!</div></div>";
        exit;
    }
} else {
    echo "<div class='container'><div class='alert alert-danger'>Invalid product ID!</div></div>";
    exit;
}
?>

<?php include "header.php"; ?>
<!-- <?php include "main_nav.php"; ?> -->


<tbody>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
								</tbody>
							</table>
							<span class="sub-tot">Sub-Total : <span>$277.60</span> | <span>Vat (17.5%)</span> : $36.00 </span>
							<br>
							<div class="btn-popcart">
								<a href="checkout.php" class="btn btn-default btn-red btn-sm">Checkout</a>
								<a href="cart.php" class="btn btn-default btn-red btn-sm">More</a>
							</div>
							<div class="popcart-tot">
								<p>
									Total<br>
									<span>$313.60</span>
								</p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- </div> end main-nav -->

	<?php
include 'config.php'; // config.php dosyasının yolunu belirtin
?>


	<div class="container">
		<ul class="small-menu"><!--small-nav -->
			<li><a href="cart3.php" class="myshop">Shopping Chart</a></li> 
			<!-- <li><a href="checkout.php" class="mycheck">Checkout</a></li> -->
			<li><a href="order.php" class="myacc">Orders</a></li> 

			<!-- Search Form -->
			<!-- <li>
            <form method="GET" action="" style="display: inline;">
                <input type="text" name="query" placeholder="Search for a product..." style="display: inline; width: 200px;">
                <button type="submit" style="display: inline;">Search</button>
            </form>
        </li> -->



		</ul><!--small-nav -->
		<div class="clearfix"></div>
		<div class="lines"></div>
	</div>












<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="bread"><a href="#">Home</a> &rsaquo; Product </div>
                            <div class="bigtitle">Product</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9">
            <div class="title-bg">
                <div class="title"><?php echo $product['product_name']; ?></div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="dt-img">
                        <div class="detpricetag"><div class="inner"><?php echo $product['product_price']; ?>$</div></div>
                        <img src="../product_images/<?php echo $product['product_image']; ?>" alt="" class="img-responsive">
                    </div>
                </div>
                <div class="col-md-6 det-desc">
                    <div class="productdata">
                        <div class="infospan">Brand <span><?php echo $product['product_brand']; ?></span></div>
                        <div class="infospan">Product No <span><?php echo $product['product_id']; ?></span></div>
                        
                        <!-- Additional product options or details can be added here -->
                        <!-- <div class="avatock"><span>In Stock</span></div> -->
                        <div class="avatock"><span>Stock: <?php echo $product['product_stock']; ?></span></div>
                    <!-- </div>
                    <div class="addtocart">
                        <form method="post" action="add_cart2.php">
                            <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                            <div class="form-group">
                                <label for="quantity">Quantity:</label>
                                <input type="number" name="quantity" class="form-control" id="quantity" value="1" min="1" max="<?php echo $product['product_stock']; ?>">
                            </div> -->


<div class="addtocart">
    <form method="post" action="add_cart.php">
        <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
        <input type="hidden" name="add_to_cart" value="1">
        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="number" name="quantity" class="form-control" id="quantity" value="1" min="1" max="<?php echo $product['product_stock']; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Add to Cart</button>
    </form>
</div>




                            <!-- <a href="add_cart2.php?product_id=<?php echo $product['product_id']; ?>" class="btn btn-primary">Add to Cart</a> -->
                            <!-- <a href="add_cart.php?product_id=<?php echo $product['product_id']; ?>"> -->
              <!-- <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button> -->
                    <!-- </a> -->
                        </form>
                       
                    </div>
                </div>
            </div>
            <div class="tab-review">
                <ul id="myTab" class="nav nav-tabs shop-tab">
                    <li class="active"><a href="#desc" data-toggle="tab">Product Description</a></li>
                </ul>
                <div id="myTabContent" class="tab-content shop-tab-ct">
                    <div class="tab-pane fade active in" id="desc">
                        <p><?php echo $product['product_detail']; ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php include "sidebar.php"; ?>
    </div>
</div>

<?php include "footer.php"; ?>
