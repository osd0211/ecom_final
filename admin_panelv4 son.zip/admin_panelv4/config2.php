<?php 

try {
    $db = new PDO("mysql:host=localhost;dbname=ecommerce24;charset=utf8", "root", "");
    
} catch (PDOException $e) {
    echo $e->getMessage();
}
?>