﻿<?php include "header.php"; ?>
<?php include "main_nav.php"; ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="page-title-wrap">
					<div class="page-title-inner">
					<div class="row">
						<div class="col-md-4">
							<div class="bread"><a href="#">Home</a> &rsaquo; Category</div>
							<div class="bigtitle">Category</div>
						</div>
						<div class="col-md-3 col-md-offset-5">
							<button class="btn btn-default btn-red btn-lg">Purchase Theme</button>
						</div>
					</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row prdct"><!--Products-->
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-3.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag on-sale"><div class="inner on-sale"><span class="onsale"><span class="oldprice">$314</span>$199</span></div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Red T-Shirt</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-1.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Nikon Camera</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-2.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Black Shoes</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-1.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Nikon Camera</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-3.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag on-sale"><div class="inner on-sale"><span class="onsale"><span class="oldprice">$314</span>$199</span></div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Red T-Shirt</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-3.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Red T-Shirt</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-2.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Black Shoes</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-1.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Nikon Camera</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-2.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Black Shoes</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-3.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Red T-Shirt</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-1.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Nikon Camera</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>		
			<div class="col-md-3">
				<div class="productwrap">
					<div class="pr-img">
						<a href="product.php"><img src="images\sample-1.jpg" alt="" class="img-responsive"></a>
						<div class="pricetag"><div class="inner">$199</div></div>
					</div>
					<span class="smalltitle"><a href="product.php">Nikon Camera</a></span>
					<span class="smalldesc">Item no.: 1000</span>
				</div>
			</div>	
		</div><!--Products-->
	<?php include "pagination.php" ; ?>
	
		<div class="spacer"></div>
	</div>
	
	<?php include "footer.php"; ?>