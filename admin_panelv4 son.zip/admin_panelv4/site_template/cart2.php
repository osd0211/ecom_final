<?php
// session_start(); // Start the sessions

include("config.php");
include "header.php";
include "main_nav.php";
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="bread"><a href="#">Home</a> &rsaquo; Cart</div>
                            <div class="bigtitle">Cart</div>
                        </div>
                        <div class="col-md-3 col-md-offset-5"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="title-bg">
        <div class="title">Cart</div>
    </div>
    
    <div class="table-responsive">
        <table class="table table-bordered chart">
            <thead>
                <tr>
                    <th>Remove</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Item No.</th>
                    <th>Unit Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $totalPrice = 0;

                // If there is a product coming from product.php, add it to the cart
            

                            
              

            </tbody>
        </table>
    </div>
    <div class="row">
        <div class="col-md-6">
            <form class="form-horizontal coupon" role="form">
                <div class="form-group">
                    <label for="coupon" class="col-sm-3 control-label">Coupon Code</label>
                    <div class="col-sm-7">
                        <input type="email" class="form-control" id="coupon" placeholder="Email">
                    </div>
                    <div class="col-sm-2">
                        <button class="btn btn-default btn-red btn-sm">Apply</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-3 col-md-offset-3">
            <div class="subtotal-wrap">
                <div class="subtotal">
                    <p>Total Price: $<?php echo $totalPrice; ?></p>
                </div>
                <div class="clearfix"></div>
                <a href="checkout.php" class="btn btn-default btn-yellow">Checkout</a>
            </div>
        </div>
    </div>
    <div class="spacer"></div>
</div>

<?php include "footer.php"; ?>