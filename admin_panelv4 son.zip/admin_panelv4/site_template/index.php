﻿<?php include "header.php"; ?>
<?php include "main_nav.php"; ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Website</title>
    <link rel="stylesheet" href="style.css">
</head>

<div class="main-slide">
    <!-- Main slide content -->
</div>

<div class="f-widget featpro">
    <div class="container">
        <div class="title-widget-bg">
            <div class="title-widget">Featured Products</div>
            <div class="carousel-nav">
                <a class="prev"></a>
                <a class="next"></a>
            </div>
        </div>
        <div id="product-carousel" class="owl-carousel owl-theme">
            <?php
            // session_start();
            ini_set('display_errors', '1');
            ini_set('display_startup_errors', '1');
            error_reporting(E_ALL);

            // Veritabanı bağlantı bilgileri
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "berkhoca_db";

            // Veritabanı bağlantısı
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Bağlantı hatası: " . $conn->connect_error);
            }

            // Rastgele ürünleri seçme sorgusu
            // $sql = "SELECT * FROM product_table ORDER BY RAND() LIMIT 5"; // 5 adet rastgele ürün alınacak
            $sql = "SELECT * FROM product_table WHERE product_stock > 0 ORDER BY RAND() LIMIT 5";

            // Sorguyu çalıştırma ve sonuçları alma
            $query_result = $conn->query($sql);
            while ($row = $query_result->fetch_assoc()) {
                echo '<div class="item">';
                echo '<div class="productwrap">';
                echo '<div class="pr-img">';
                echo '<a href="product.php?product_id=' . $row["product_id"] . '"><img src="../product_images/' . $row["product_image"] . '" alt="" class="img-responsive"></a>'; // Ürün resmini dinamik olarak çekiyoruz ve detay sayfasına yönlendirme ekliyoruz
                echo '<div class="pricetag blue"><div class="inner"><span>$' . $row["product_price"] . '</span></div></div>';
                echo '</div>';
                echo '<span class="smalltitle"><a href="product.php?product_id=' . $row["product_id"] . '">' . $row["product_name"] . '</a></span>'; // Ürün adının da detay sayfasına yönlendirmesini ekliyoruz
                echo '<span class="smalldesc">Item no.: ' . $row["product_id"] . '</span>';
                echo '</div>';
                echo '</div>';
            }

            // Bağlantıyı kapatma
            $conn->close();
            ?>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-9"><!--Main content-->
            <div class="title-bg">
                <div class="title">Latest Products</div>
            </div>
            <div class="row prdct"><!--Products-->
                <?php
                // Veritabanı bağlantı bilgileri ve rastgele ürünleri alma kodu yukarıda olduğu için tekrar eklemiyorum.
                $conn = new mysqli($servername, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("Bağlantı hatası: " . $conn->connect_error);
                }

                // En yüksek product_id'ye sahip olan ürünü en başta göstermek için sorguyu güncelliyoruz
                $sql = "SELECT * FROM product_table WHERE product_stock > 0 ORDER BY product_id DESC LIMIT 6";

                // Sorguyu çalıştırma ve sonuçları alma
                $query_result = $conn->query($sql);
                $counter = 0;
                while ($row = $query_result->fetch_assoc()) {
                    if ($counter < 6) { // Döngüyü 6 ürünle sınırlıyoruz
                        echo '<div class="col-md-4">';
                        echo '<div class="productwrap">';
                        echo '<div class="pr-img">';
                        echo '<a href="product.php?product_id=' . $row["product_id"] . '"><img src="../product_images/' . $row["product_image"] . '" alt="" class="img-responsive"></a>'; // Ürün resmini dinamik olarak çekiyoruz ve detay sayfasına yönlendirme ekliyoruz
                        echo '</div>';
                        echo '<div class="pr-info">';
                        echo '<span class="smalltitle"><a href="product.php?product_id=' . $row["product_id"] . '">' . $row["product_name"] . '</a></span>'; // Ürün adının da detay sayfasına yönlendirmesini ekliyoruz
                        echo '<span class="smalldesc">Item no.: ' . $row["product_id"] . '</span>';
                        echo '<div class="pricetag"><div class="inner">$' . $row["product_price"] . '</div></div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        $counter++;
                    }
                }

                // Bağlantıyı kapatma
                $conn->close();
                ?>
    
            </div><!--Products-->
            <div class="spacer"></div>
        </div> <!-- Main content -->

        <?php include "sidebar.php"; ?>

    </div><!--Row-->
</div><!--Container-->

<?php include "footer.php"; ?>
