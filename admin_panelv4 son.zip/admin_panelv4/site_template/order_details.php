<?php
include("config.php");
include "header.php";
// include "main_nav.php";

// Veritabanı bilgileri
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "berkhoca_db";

// Veritabanı bağlantısını oluştur
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>




<tbody>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
								</tbody>
							</table>
							<span class="sub-tot">Sub-Total : <span>$277.60</span> | <span>Vat (17.5%)</span> : $36.00 </span>
							<br>
							<div class="btn-popcart">
								<a href="checkout.php" class="btn btn-default btn-red btn-sm">Checkout</a>
								<a href="cart.php" class="btn btn-default btn-red btn-sm">More</a>
							</div>
							<div class="popcart-tot">
								<p>
									Total<br>
									<span>$313.60</span>
								</p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- </div> end main-nav -->

	<?php
include 'config.php'; // config.php dosyasının yolunu belirtin
?>


	<div class="container">
		<ul class="small-menu"><!--small-nav -->
			<li><a href="cart3.php" class="myshop">Shopping Chart</a></li> 
			<!-- <li><a href="checkout.php" class="mycheck">Checkout</a></li> -->
			<li><a href="order.php" class="myacc">Orders</a></li> 

			<!-- Search Form -->
			<!-- <li>
            <form method="GET" action="" style="display: inline;">
                <input type="text" name="query" placeholder="Search for a product..." style="display: inline; width: 200px;">
                <button type="submit" style="display: inline;">Search</button>
            </form>
        </li> -->



		</ul><!--small-nav -->
		<div class="clearfix"></div>
		<div class="lines"></div>
	</div>










<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="bread"><a href="#">Home</a> &rsaquo; Order Details</div>
                            <div class="bigtitle">Order Details</div>
                        </div>
                        <div class="col-md-3 col-md-offset-5"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="title-bg">
        <div class="title">Order Details</div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Image</th>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // URL'den order_id al
            $order_id = isset($_GET['order_id']) ? $_GET['order_id'] : null;

            if ($order_id === null) {
                die("No order ID provided.");
            }

            // Sipariş detaylarını order_detail_table tablosundan çek
            $sql = "SELECT product_id, quantity FROM order_detail_table WHERE order_id = '$order_id'";
            $result = $conn->query($sql);
            $total_price = 0; // Toplam fiyatı tutmak için değişken

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $product_id = $row['product_id'];
                    $quantity = $row['quantity'];

                    // Ürün bilgilerini getir
                    $product_info_sql = "SELECT product_name, product_price, product_image FROM product_table WHERE product_id = '$product_id'";
                    $product_info_result = $conn->query($product_info_sql);
                    if ($product_info_result->num_rows > 0) {
                        $product_info = $product_info_result->fetch_assoc();
                        $product_name = $product_info['product_name'];
                        $product_price = $product_info['product_price'];
                        $product_image = $product_info['product_image'];

                        $total_price += $product_price * $quantity; // Toplam fiyatı güncelle

                        echo "<tr>
                                <td><img src='../product_images/$product_image' alt='$product_name' width='100'></td>
                                <td>$product_id</td>
                                <td>$product_name</td>
                                <td>$quantity</td>
                                <td>$product_price</td>
                                <td>" . ($product_price * $quantity) . "</td>
                            </tr>";
                    }
                }
            } else {
                echo "<tr><td colspan='6'>No details found for this order.</td></tr>";
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="5"><strong>Total Price:</strong></td>
                <td><?php echo $total_price; ?></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php include "footer.php"; ?>
