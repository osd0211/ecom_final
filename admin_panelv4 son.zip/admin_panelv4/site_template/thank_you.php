<?php
include("header.php");
include "main_nav.php";
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="bread"><a href="#">Home</a> &rsaquo; Thank You</div>
                            <div class="bigtitle">Thank You</div>
                        </div>
                        <div class="col-md-3 col-md-offset-5"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="title-bg">
        <div class="title">Thank You for Your Order!</div>
    </div>
    <div class="spacer"></div>
</div>

<?php include "footer.php"; ?>
