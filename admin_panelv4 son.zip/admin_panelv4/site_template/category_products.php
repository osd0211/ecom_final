
<?php
// include("config.php");

// Veritabanı bağlantısını yap
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "berkhoca_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// Kategori ID'sini al
if (isset($_GET['category_id'])) {
    $category_id = $_GET['category_id'];

    $sql = "SELECT p.*, c.category_name, c.category_detail 
    FROM product_table p 
    LEFT JOIN category_table c 
    ON p.category_id = c.category_id 
    WHERE p.category_id = $category_id AND p.product_stock > 0";
    $result = $conn->query($sql);

    $products = [];
    $category_name = '';
    $category_detail = '';
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Kategori bilgilerini al
            $category_name = $row['category_name'];
            $category_detail = $row['category_detail'];

            // Ürün resim dosyasının mevcut olup olmadığını kontrol et
            if (file_exists("../product_images/" . $row['product_image'])) {
                $row['product_image'] = "../product_images/" . $row['product_image']; // Resim yolunu güncelle
                $products[] = $row;
            } else {
                $row['product_image'] = 'default.jpg'; // Eğer resim yoksa varsayılan bir resim kullan
                $products[] = $row;
            }
        }
    } else {
        echo "Bu kategoride ürün bulunamadı.";
    }
} else {
    echo "Kategori belirtilmedi.";
}
?>


<?php include "header.php"; ?>
<!-- <?php include "main_nav.php"; ?> -->



<tbody>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
								</tbody>
							</table>
							<span class="sub-tot">Sub-Total : <span>$277.60</span> | <span>Vat (17.5%)</span> : $36.00 </span>
							<br>
							<div class="btn-popcart">
								<a href="checkout.php" class="btn btn-default btn-red btn-sm">Checkout</a>
								<a href="cart.php" class="btn btn-default btn-red btn-sm">More</a>
							</div>
							<div class="popcart-tot">
								<p>
									Total<br>
									<span>$313.60</span>
								</p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- </div> end main-nav -->

	<?php
include 'config.php'; // config.php dosyasının yolunu belirtin
?>


	<div class="container">
		<ul class="small-menu"><!--small-nav -->
			<li><a href="cart3.php" class="myshop">Shopping Chart</a></li> 
			<!-- <li><a href="checkout.php" class="mycheck">Checkout</a></li> -->
			<li><a href="order.php" class="myacc">Orders</a></li> 

			<!-- Search Form -->
			<!-- <li>
            <form method="GET" action="" style="display: inline;">
                <input type="text" name="query" placeholder="Search for a product..." style="display: inline; width: 200px;">
                <button type="submit" style="display: inline;">Search</button>
            </form>
        </li> -->



		</ul><!--small-nav -->
		<div class="clearfix"></div>
		<div class="lines"></div>
	</div>















<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="bread"><a href="#">Home</a> &rsaquo;  <?php echo $category_name; ?></div>
                            <div class="bigtitle"><?php echo $category_name; ?></div>
                            <p><?php echo $category_detail; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9"><!--Main content-->
            <div class="title-bg">
                <div class="title">Category Products</div>
            </div>
            <div class="row prdct"><!--Products-->
                <?php foreach ($products as $product): ?>
                    <div class="col-md-4">
                        <div class="productwrap">
                            <div class="pr-img">
                                <a href="product.php?product_id=<?php echo $product['product_id']; ?>">
                                    <img src="<?php echo $product['product_image']; ?>" alt="" class="img-responsive">
                                </a>
                                <div class="pricetag"><div class="inner">$<?php echo $product['product_price']; ?></div></div>
                            </div>
                            <span class="smalltitle">
                                <a href="product.php?product_id=<?php echo $product['product_id']; ?>">
                                    <?php echo $product['product_name']; ?>
                                </a>
                            </span>
                            <span class="smalldesc">Item no.: <?php echo $product['product_id']; ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div><!--Products-->
            
        </div>
        <?php include "sidebar.php"; ?>
    </div>
</div>
<?php include "footer.php"; ?>
