<?php
include("config.php");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['name']) && isset($_POST['surname']) && isset($_POST['address']) && isset($_POST['city']) && isset($_POST['email']) && isset($_POST['phone'])) {
        $customer_name = $_POST['name'];
        $customer_surname = $_POST['surname'];
        $customer_address = $_POST['address'];
        $customer_city = $_POST['city'];
        $customer_email = $_POST['email'];
        $customer_phone = $_POST['phone'];

        // Veritabanı bağlantısını oluştur
        $conn = new mysqli("localhost", "root", "", "berkhoca_db");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Dış anahtar kısıtlamasını geçici olarak devre dışı bırak
        $sql_disable_fk = "SET FOREIGN_KEY_CHECKS=0";
        $conn->query($sql_disable_fk);

        // Sepet tablosundan cart_id'yi al
        $sql_select_cart_id = "SELECT cart_id FROM cart_table LIMIT 1";
        $result = $conn->query($sql_select_cart_id);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $cart_id = $row['cart_id'];
        } else {
            die("No items in the cart.");
        }

        // Müşteri bilgilerini checkout_table'a kaydet
        $sql_insert_checkout = "INSERT INTO checkout_table (customer_name, customer_surname, customer_address, customer_city, customer_email, customer_phone, cart_id) 
                                VALUES ('$customer_name', '$customer_surname', '$customer_address', '$customer_city', '$customer_email', '$customer_phone', '$cart_id')";

        if ($conn->query($sql_insert_checkout) === TRUE) {
            echo "Order inserted into checkout_table successfully.<br>";

            // Sipariş detaylarını order_detail_table'a ekle
            $sql_insert_order_detail = "INSERT INTO order_detail_table (order_id, product_id, quantity) 
                                        SELECT LAST_INSERT_ID(), product_id, quantity FROM cart_table";
            if ($conn->query($sql_insert_order_detail) === TRUE) {
                echo "Order detail inserted successfully.<br>";



                 // Ürünlerin stok miktarını güncelle
                 $sql_update_stock = "UPDATE product_table p
                 JOIN cart_table c ON p.product_id = c.product_id
                 SET p.product_stock = p.product_stock - c.quantity";
             if ($conn->query($sql_update_stock) === TRUE) {
            echo "Stock updated successfully.<br>";






                // Sepeti temizle
                $sql_delete_cart = "DELETE FROM cart_table";
                $conn->query($sql_delete_cart);

                // Dış anahtar kısıtlamasını tekrar etkinleştir
                $sql_enable_fk = "SET FOREIGN_KEY_CHECKS=1";
                $conn->query($sql_enable_fk);

                // Bağlantıyı kapat
                $conn->close();

                // İşlem tamamlandıktan sonra kullanıcıyı teşekkür sayfasına yönlendir
                header("Location: thank_you.php");
                exit;
            } else {
                echo "Error inserting order detail: " . $conn->error . "<br>";
            }
        } else {
            echo "Error inserting checkout info: " . $conn->error . "<br>";
        }

        // Bağlantıyı kapat
        $conn->close();
    } else {
        echo "You did not enter all required information.";
        echo '<pre>' . print_r($_POST, true) . '</pre>'; // Debugging için POST verilerini yazdır
    }
} else {
    echo "Form not submitted.";
}

}
?>
