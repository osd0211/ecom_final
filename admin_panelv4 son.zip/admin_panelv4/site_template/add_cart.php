<?php
include("config2.php"); 

if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];

    
    $sql = "SELECT product_stock FROM product_table WHERE product_id = $product_id";
    $result = berkhoca_query_parser($sql); 

    if ($result && count($result) > 0) {
        $row = $result[0];
        $stock = $row['product_stock'];

        if ($quantity <= $stock) {
            
            $sql = "SELECT * FROM cart_table WHERE product_id = $product_id";
            $cart_result = berkhoca_query_parser($sql);

            if ($cart_result && count($cart_result) > 0) {
                
                $sql = "UPDATE cart_table SET quantity = quantity + $quantity WHERE product_id = $product_id";
            } else {
                
                $sql = "INSERT INTO cart_table (product_id, quantity) VALUES ($product_id, $quantity)";
            }
            $result = berkhoca_query_parser($sql);
        } else {
           
            echo "Sorry, the requested quantity exceeds available stock.";
            exit;
        }
    } else {
        
        echo "Product not found.";
        exit;
    }
}


header("Location: cart3.php");
exit;
?>
