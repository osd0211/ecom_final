<table class="table table-condensed popcart-inner">
								<tbody>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
									<tr>
										<td>
										<a href="product.php"><img src="images\dummy-1.png" alt="" class="img-responsive"></a>
										</td>
										<td><a href="product.php">Casio Exilim Zoom</a><br><span>Color: green</span></td>
										<td>1X</td>
										<td>$138.80</td>
										<td><a href=""><i class="fa fa-times-circle fa-2x"></i></a></td>
									</tr>
								</tbody>
							</table>
							<span class="sub-tot">Sub-Total : <span>$277.60</span> | <span>Vat (17.5%)</span> : $36.00 </span>
							<br>
							<div class="btn-popcart">
								<a href="checkout.php" class="btn btn-default btn-red btn-sm">Checkout</a>
								<a href="cart.php" class="btn btn-default btn-red btn-sm">More</a>
							</div>
							<div class="popcart-tot">
								<p>
									Total<br>
									<span>$313.60</span>
								</p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- </div> end main-nav -->

	<?php
include 'config.php'; // config.php dosyasının yolunu belirtin
?>


	<div class="container">
		<ul class="small-menu"><!--small-nav -->
			<li><a href="cart3.php" class="myshop">Shopping Chart</a></li> 
			<!-- <li><a href="checkout.php" class="mycheck">Checkout</a></li> -->
			<li><a href="order.php" class="myacc">Orders</a></li> 

			<!-- Search Form -->
			<li>
            <form method="GET" action="" style="display: inline;">
                <input type="text" name="query" placeholder="Search for a product..." style="display: inline; width: 200px;">
                <button type="submit" style="display: inline;">Search</button>
            </form>
        </li>



		</ul><!--small-nav -->
		<div class="clearfix"></div>
		<div class="lines"></div>
	</div>


	<style>
    /* CSS Stil Kodları */
    .search-results ul {
        list-style-type: none;
        padding: 0;
    }

    .search-results li {
        display: inline-block;
        margin: 10px;
        width: 200px;
        border: 1px solid #ccc;
        padding: 10px;
        text-align: center;
    }

    .search-results li a {
        color: #333;
        text-decoration: none;
    }

    .search-results li a:hover {
        color: #007bff;
    }

    .product-image {
        max-width: 100%;
        height: auto;
        margin-bottom: 10px;
    }
</style>

<!-- Search Results -->
<div class="search-results">
    <?php
    if (isset($_GET['query'])) {
        $query = $_GET['query'];
        $likeQuery = "%" . $query . "%";
        $sql = "SELECT * FROM product_table WHERE product_name LIKE '$likeQuery'";
        $results = berkhoca_query_parser($sql);

        if (count($results) > 0) {
            echo "<ul>";
            foreach ($results as $product) {
                echo "<li>";
                echo "<a href='product.php?product_id=" . $product['product_id'] . "'>";
                echo "<div class='product-item'>";
                echo "<img src='product_images/" . $product['product_image'] . "' alt='" . htmlspecialchars($product['product_name']) . "' class='product-image'>";
                echo "<h3>" . htmlspecialchars($product['product_name']) . "</h3>";
                echo "<p>Price: $" . $product['product_price'] . "</p>";
                echo "</div>";
                echo "</a>";
                echo "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>No products found.</p>";
        }
    }
    ?>
</div>
