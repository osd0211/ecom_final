﻿<?php include "header.php"; ?>
<?php include "main_nav.php"; ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="bread"><a href="#">Home</a> &rsaquo; Orders</div>
                            <div class="bigtitle">Orders</div>
                        </div>
                        <div class="col-md-3 col-md-offset-5">
                            <!-- <button class="btn btn-default btn-red btn-lg">Purchase Theme</button> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="title-bg">
        <div class="title">Orders</div>
    </div>
    
    <div class="table-responsive">
        <table class="table table-bordered chart">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Veritabanı bağlantısını oluştur
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "berkhoca_db";

                $conn = new mysqli($servername, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Siparişleri `checkout_table` tablosundan çek
                $sql = "SELECT order_id, customer_name, customer_surname, customer_address, customer_city, customer_email, customer_phone, cart_id 
                        FROM checkout_table";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        // Sipariş detaylarını çek
                        $order_id = $row['order_id'];
                        $customer_name = $row['customer_name'];
                        $customer_surname = $row['customer_surname'];
                        $customer_address = $row['customer_address'];
                        $customer_city = $row['customer_city'];
                        $customer_email = $row['customer_email'];
                        $customer_phone = $row['customer_phone'];
                        $cart_id = $row['cart_id'];
                        
                        // Model ve Fiyat gibi detayları `cart_table` veya ilgili tablodan çekmeniz gerekebilir
                        // $sql_cart = "SELECT product_name, product_price FROM cart_table WHERE cart_id = $cart_id";
                        // $cart_result = $conn->query($sql_cart);
                        // $products = [];
                        // $total_price = 0;

                        // if ($cart_result->num_rows > 0) {
                        //     while($cart_row = $cart_result->fetch_assoc()) {
                        //         $products[] = $cart_row['product_name'];
                        //         $total_price += $cart_row['product_price'];
                        //     }
                        // }

                        // $model = implode(", ", $products);
                        // $status = "Completed"; // Bu sabit bir değer, duruma göre değiştirilebilir

                        echo "<tr>
                                <td>$order_id</td>
                                <td>$customer_name</td>
                                <td>$customer_surname</td>
                                <td>$customer_address</td>
                                <td>$customer_city</td>
                                <td>$customer_email</td>
                                <td>$customer_phone</td>
                                <td><a href='order_details.php?order_id=$order_id'><i class='fa fa-eye'></i> View Details</a></td>
                            </tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No orders found.</td></tr>";
                }

                // Veritabanı bağlantısını kapat
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
    <div class="spacer"></div>
</div>

<?php include "footer.php"; ?>
