<?php
include("config2.php"); // Veritabanı bağlantısını dahil et

if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = $_POST['product_id'];
    $quantity = (int)$_POST['quantity'];

    // Ürün stok miktarını veritabanından kontrol et
    $sql = "SELECT product_stock FROM product_table WHERE product_id = $product_id";
    $result = berkhoca_query_parser($sql); // config.php'den sorgu ayrıştırıcı fonksiyonunu kullan

    if ($result && count($result) > 0) {
        $row = $result[0];
        $stock = $row['product_stock'];

        if ($quantity <= $stock) {
            if ($quantity == 0) {
                // Eğer miktar 0 ise ürünü sepetten çıkar
                $sql = "DELETE FROM cart_table WHERE product_id = $product_id";
            } else {
                // Ürün miktarını güncelle
                $sql = "UPDATE cart_table SET quantity = $quantity WHERE product_id = $product_id";
            }
            $result = berkhoca_query_parser($sql);
        } else {
            // Hata mesajı: İstenen miktar stoktan fazla
            $_SESSION['error'] = "Sorry, the requested quantity exceeds available stock.";
        }
    }
}

// Sepet sayfasına geri yönlendir
header("Location: cart3.php");
exit;
?>
