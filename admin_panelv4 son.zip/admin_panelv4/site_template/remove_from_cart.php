<?php
include("config2.php"); // Veritabanı bağlantısını dahil et

if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];

    // Ürünü sepetten çıkar
    $sql = "DELETE FROM cart_table WHERE product_id = $product_id";
    $result = berkhoca_query_parser($sql);
}

// Sepet sayfasına geri yönlendir
header("Location: cart3.php");
exit;
?>
