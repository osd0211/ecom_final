<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

function berkhoca_query_parser($sql='') {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "berkhoca_db";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (empty($sql)) {
        return 'SQL statement is empty';
    }

    $query_result = $conn->query($sql);
    
    if ($query_result === FALSE) {
        die("SQL Error: " . $conn->error . " in query: " . $sql);
    }

    // SELECT sorguları için
    if (stripos($sql, 'SELECT') === 0) {
        $array_result = [];
        while ($row = $query_result->fetch_assoc()) {
            $array_result[] = $row;
        }
        $conn->close();
        return $array_result;
    }

    // Diğer sorgular için (INSERT, UPDATE, DELETE)
    $conn->close();
    return true;
}
?>
