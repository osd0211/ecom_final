﻿<?php
// session_start(); 

include("config.php");
include "header.php";
include "main_nav.php";
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-title-wrap">
                <div class="page-title-inner">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="bread"><a href="#">Home</a> &rsaquo; Cart</div>
                            <div class="bigtitle">Cart</div>
                        </div>
                        <div class="col-md-3 col-md-offset-5"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="title-bg">
        <div class="title">Cart</div>
    </div>
    
    <div class="table-responsive">
        <table class="table table-bordered chart">
            <thead>
                <tr>
                    <th>Remove</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Item No.</th>
                    <th>Unit Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $totalPrice = 0;

                
                if(isset($_POST['add_to_cart']) && isset($_POST['product_id']) && isset($_POST['quantity'])) {
                    $product_id = $_POST['product_id'];
                    $quantity = (int)$_POST['quantity'];

                    
                    $sql = "SELECT * FROM product_table WHERE product_id = $product_id";
                    $result = berkhoca_query_parser($sql); 

                    if($result && count($result) > 0) {
                        $row = $result[0]; 

                        // Stock control
                        if($row['product_stock'] >= $quantity) {
                            $found = false;
                            // Check if the product is already in cart
                            if(isset($_SESSION['cart'])) {
                                foreach($_SESSION['cart'] as $key => $item) {
                                    if($item['id'] == $product_id) {
                                        $found = true;
                                        $_SESSION['cart'][$key]['quantity'] += $quantity; // Update quantity
                                        break;
                                    }
                                }
                            }

                            if(!$found) {
                                // Add the product to cart
                                $_SESSION['cart'][] = array(
                                    'name' => $row['product_name'],
                                    'id' => $row['product_id'],
                                    'price' => $row['product_price'],
                                    'image' => '../product_images/' . $row['product_image'],
                                    'quantity' => $quantity
                                );
                            }
                        } else {
                            echo '<tr><td colspan="7">Sorry, this product has reached its stock limit.</td></tr>';
                        }
                    }
                }

                if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
                    foreach($_SESSION['cart'] as $key => $cartItem) {
                        
                        if (!isset($cartItem['quantity'])) {
                            $cartItem['quantity'] = 1; 
                        }

                        echo '<tr>
                            <td><a href="remove_from_cart.php?item_id='.$cartItem['id'].'" class="btn btn-danger">Remove</a></td>
                            <td><img src="../product_images/'.$cartItem['image'].'" width="100" alt=""></td>
                            <td>'.$cartItem['name'].'</td>
                            <td>'.$cartItem['id'].'</td>
                            <td>'.$cartItem['price'].'</td>
                            <td>
                                <form action="update_cart.php" method="post">
                                    <input type="hidden" name="item_id" value="'.$cartItem['id'].'">
                                    <input type="number" name="quantity" value="'.$cartItem['quantity'].'" min="0">
                                    <button type="submit" class="btn btn-success">Update</button>
                                </form>
                            </td>
                            <td>'.$cartItem['price'] * $cartItem['quantity'].'</td>
                        </tr>';

                        $totalPrice += $cartItem['price'] * $cartItem['quantity'];
                    }
                } else {
                    echo '<tr><td colspan="7">Your cart is empty.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <div class="row">
        <div class="col-md-6">
            <form class="form-horizontal coupon" role="form">
                <div class="form-group">
                    <label for="coupon" class="col-sm-3 control-label">Coupon Code</label>
                    <div class="col-sm-7">
                        <input type="email" class="form-control" id="coupon" placeholder="Email">
                    </div>
                    <div class="col-sm-2">
                        <button class="btn btn-default btn-red btn-sm">Apply</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-3 col-md-offset-3">
            <div class="subtotal-wrap">
                <div class="subtotal">
                    <p>Total Price: $<?php echo $totalPrice; ?></p>
                </div>
                <div class="clearfix"></div>
                <a href="checkout.php" class="btn btn-default btn-yellow">Checkout</a>
            </div>
        </div>
    </div>
    <div class="spacer"></div>
</div>

<?php include "footer.php"; ?>