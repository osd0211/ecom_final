<footer id="footer">
    <ul class="nav pull-right">
        <li>
            Copyright &copy; 2013, Jumpstart Themes.
        </li>
    </ul>
</footer>

<script src="admin_template/Theme/js/libs/jquery-1.9.1.min.js"></script>
<script src="admin_template/Theme/js/libs/jquery-ui-1.9.2.custom.min.js"></script>
<script src="admin_template/Theme/js/libs/bootstrap.min.js"></script>

<script src="admin_template/Theme/js/plugins/icheck/jquery.icheck.min.js"></script>
<script src="admin_template/Theme/js/plugins/select2/select2.js"></script>
<script src="admin_template/Theme/js/plugins/tableCheckable/jquery.tableCheckable.js"></script>

<script src="admin_template/Theme/js/App.js"></script>

<script src="admin_template/Theme/js/libs/raphael-2.1.2.min.js"></script>
<script src="admin_template/Theme/js/plugins/morris/morris.min.js"></script>

<script src="admin_template/Theme/js/demos/charts/morris/area.js"></script>
<script src="admin_template/Theme/js/demos/charts/morris/donut.js"></script>

<script src="admin_template/Theme/js/plugins/sparkline/jquery.sparkline.min.js"></script>

<script src="admin_template/Theme/js/plugins/fullcalendar/fullcalendar.min.js"></script>
<script src="admin_template/Theme/js/demos/calendar.js"></script>

<script src="admin_template/Theme/js/demos/dashboard.js"></script>