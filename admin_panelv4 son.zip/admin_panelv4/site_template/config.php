<?php 
// session_start();
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

if (!function_exists('berkhoca_query_parser')) {
    function berkhoca_query_parser($sql='') {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "berkhoca_db";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (empty($sql)) {
            return 'sql statement is empty';
        }
        $query_result = $conn->query($sql);
        $array_result = [];
        while ($row = $query_result->fetch_assoc()) {
            $array_result[] = $row;
        }
        return $array_result;
    }
}
?>